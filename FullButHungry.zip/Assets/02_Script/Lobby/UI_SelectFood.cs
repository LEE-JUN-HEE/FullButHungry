﻿using UnityEngine;
using System.Collections;

public class UI_SelectFood : MonoBehaviour {
    public void Show()
    {
    }


    public void Hide()
    {
        gameObject.SetActive(false);
    }
}
